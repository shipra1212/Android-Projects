package com.example.Intent_programe5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class Page3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page3);
    }



    public void verMapaLocal(View view)
    {

        Uri location= Uri.parse("https://goo.gl/maps/WUSK9K9adZqyLRh57");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, location);
        startActivity(mapIntent );

    }

    public void fazerChamada(View view)
    {
        Uri uri = Uri.parse("tel:08040129600");
        Intent it = new Intent(Intent.ACTION_DIAL, uri);
        startActivity(it);

    }


    public void enviarEmail(View view) throws UnsupportedEncodingException {


        String uriText =
                "mailto:shiprajha000@gmail.com" +
                        "?subject=" + URLEncoder.encode("assunto do email", "utf-8") +
                        "&body=" + URLEncoder.encode("texto do email", "utf-8");
        Uri uri = Uri.parse(uriText);
        //inicia a Intent
        Intent it = new Intent(Intent.ACTION_SENDTO);
        //Define o conteúdo
        it.setData(uri);
        //Inicia a activity para enviar o email
        startActivity(Intent.createChooser(it, getString(R.string.sendEmail)));

    }

    public void efetuarBusca(View view)
    {
        Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
        String query = "Christ University";
        intent.putExtra(SearchManager.QUERY, query);
        startActivity(intent);


    }





}
