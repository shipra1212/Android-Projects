package com.example.Intent_programe5;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class HomePage extends AppCompatActivity {
    ListView listView;
    ArrayList<String> list;
    Button btn_add, btn_delete, btn_data;
    EditText editText;
    ArrayAdapter<String> arrayAdapter;
    private Context context;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);

        //object reference
        listView = (ListView) findViewById(R.id.hp_listview);
        btn_add = (Button) findViewById(R.id.hp_add);
        editText = (EditText) findViewById(R.id.hp_text);
        list = new ArrayList<String>();
        arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, list);
        btn_delete = (Button) findViewById(R.id.hp_delete);
        btn_data = (Button) findViewById(R.id.data_access);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = editText.getText().toString();
                list.add(text);
                listView.setAdapter(arrayAdapter);
                arrayAdapter.notifyDataSetChanged();
            }
        });
        btn_delete.setOnClickListener((view -> {
            for(int i=0; i<list.size(); i++){
                String text = editText.getText().toString();
                if(list.get(i).equals(text)){
                    list.remove(i);
                    arrayAdapter.notifyDataSetChanged();
                    break;
                }
                else {
                    Toast.makeText(HomePage.this, "No Rows selected!", Toast.LENGTH_SHORT).show();
                }
            }
        }));
        btn_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = editText.getText().toString();
                Intent i2 = new Intent(HomePage.this, Page3.class);
                startActivity(i2);
            }
        });
    }
}
