# RecyclerViewInAndroidStudio

Recycler view code same as whats app 
You can watch the video for better understanding of code
Link Given in Profile

![WhatsApp Image 2020-11-02 at 2 20 55 AM](https://user-images.githubusercontent.com/64765400/98062252-82e8e100-1e02-11eb-8aaf-4f5a6be77f73.jpeg)
