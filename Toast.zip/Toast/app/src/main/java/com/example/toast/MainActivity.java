package com.example.toast;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    static int count = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.button);
        EditText textBox = findViewById(R.id.textField);
        TextView tv = findViewById(R.id.textView);

        tv.setText(String.valueOf(count));


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String text = textBox.getText().toString();
                if(text.equals(""))text = "Type Something";

                count += 1;
                tv.setText(String.valueOf(count));

                Toast toast = Toast.makeText(getBaseContext(),  text, Toast.LENGTH_SHORT);
                View view2 = toast.getView();
                TextView tv2 = (TextView) view2.findViewById(android.R.id.message);
                tv2.setTextColor(Color.RED);
                view2.setBackgroundColor(Color.GREEN);
                toast.show();
            }
        });




    }
}