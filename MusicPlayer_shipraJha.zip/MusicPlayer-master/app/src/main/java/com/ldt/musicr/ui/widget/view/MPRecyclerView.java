package com.ldt.musicr.ui.widget.view;

import android.content.Context;
import android.util.AttributeSet;

import com.ldt.musicr.addon.fastscrollrecyclerview.FastScrollRecyclerView;

public class MPRecyclerView extends FastScrollRecyclerView {
    public MPRecyclerView(Context context) {
        super(context);
    }

    public MPRecyclerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MPRecyclerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
