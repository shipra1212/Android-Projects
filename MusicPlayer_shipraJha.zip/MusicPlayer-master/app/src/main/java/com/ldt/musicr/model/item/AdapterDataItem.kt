package com.ldt.musicr.model.item

interface AdapterDataItem