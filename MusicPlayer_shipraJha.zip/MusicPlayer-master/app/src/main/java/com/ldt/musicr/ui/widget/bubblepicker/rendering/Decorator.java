package com.ldt.musicr.ui.widget.bubblepicker.rendering;

public interface Decorator {
    float getCircleRadiusUnit(float width, float height);
}
