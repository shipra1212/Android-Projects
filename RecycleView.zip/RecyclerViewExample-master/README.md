# RecyclerViewExample
Android RecyclerView With CardView and OnItemClickListener Example | RecyclerView OnClickListener Example 

Subscribe My Channel #codingwitdev for more latest videos..
Watch Tutorial on -
[Youtube](https://youtu.be/ZTg-oXaCgBk)

![GitHub Logo](/recycler_view.jpg)
