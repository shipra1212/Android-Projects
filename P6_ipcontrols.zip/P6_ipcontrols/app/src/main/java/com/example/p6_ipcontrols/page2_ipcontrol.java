package com.example.p6_ipcontrols;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class page2_ipcontrol extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2_ipcontrol);
    }
}