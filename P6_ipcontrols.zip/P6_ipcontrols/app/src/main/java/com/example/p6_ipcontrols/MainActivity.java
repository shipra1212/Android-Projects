package com.example.p6_ipcontrols;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.ToggleButton;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button var = findViewById(R.id.button);
        var.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), page2_ipcontrol.class);
                startActivity(i);
            }
        });

        FloatingActionButton var1=findViewById(R.id.floatingActionButton);
        var1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent i = new Intent(getApplicationContext(), pg3_ipcontrol_rating.class);
            startActivity(i);
            }
        });

        ArrayAdapter adapter = ArrayAdapter.createFromResource(
                getApplicationContext(),
                R.array.name,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(adapter);
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);

        int currentNightMode = (new Configuration()).uiMode & Configuration.UI_MODE_NIGHT_MASK;
        switch (currentNightMode) {
            case Configuration.UI_MODE_NIGHT_NO:
                toggle.setChecked(false);
                break;
            case Configuration.UI_MODE_NIGHT_YES:
                toggle.setChecked(true);
                break;
        }


        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b)
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                else
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

            }
        });
    }

//    public void page3(View view) {
//        Intent intent = new Intent(this, page2_ipcontrol.class);
//          startActivity(intent);
//    }
}