package com.example.p6_ipcontrols;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RatingBar;

import com.google.android.material.snackbar.Snackbar;

public class pg3_ipcontrol_rating extends AppCompatActivity {

    private WebView  webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pg3_ipcontrol_rating);

        webView = findViewById(R.id.webView);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.loadUrl("https://codelabs.developers.google.com/?cat=Android");


        ((RatingBar)findViewById(R.id.ratingBar)).setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                Snackbar.make(
                        ratingBar,
                        v > 3 ? "Thanks for rating!!" : "WE will try to improve",
                        Snackbar.LENGTH_LONG
                ).show();

            }
        });
    }
}